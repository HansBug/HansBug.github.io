# BanG Dream deskpet Live2D resource audit dataset

Generated at: 2026-06-14T09:06:44.501Z

Repository issue: https://github.com/HansBug/HansBug.github.io/issues/23

## Files

- `current-pool-coverage.csv`: current local deskpet pool, including local/upstream code mapping.
- `compatible-candidates-covered-characters.csv`: Bestdori `live2d.chara` index candidates that map to currently covered deskpet characters. Despite the historical filename, rows in this CSV are index candidates, not proof that every row has already been downloaded, converted, and browser-validated.
- `character-candidate-summary.csv`: per-character counts and recommended priority buckets.
- `bestdori-live2d-chara-union.csv`: full non-general union across jp/cn/en/kr/tw Bestdori asset indexes.
- `missing-our-notes-characters.csv`: official Our Notes missing characters and current index-candidate status.
- `candidate-resource-intelligence.csv`: enriched per-candidate intelligence table. It joins Bestdori costume/detail/card/event/gacha metadata where possible, records real-heat-source absence, adds deterministic selection proxy fields, and reserves content-safety review fields.
- `candidate-selection-shortlist.csv`: conservative 500-row shortlist derived from `candidate-resource-intelligence.csv` (`currently_in_pool=no`, proxy bucket A/B, excluding filename-level sensitive hints). This is only a triage aid, not an approval list.
- `candidate-intelligence-by-family.csv`: per-family summary of metadata coverage, card/event/gacha mapping, sensitive-review hints, and average proxy score.
- `resource-intelligence-summary.json`: machine-readable summary for the intelligence enrichment pass.
- `dataset-summary.json`: machine-readable totals for the base resource audit.

## Compatibility Boundary

This dataset treats Bestdori `live2d/chara` entries as **index candidates / pending conversion candidates** when they satisfy the CSV filters. A costume becomes a confirmed project-compatible deskpet resource only after a later PR:

1. confirms the key still exists in Bestdori `_info.json -> live2d.chara`;
2. fetches `buildData.asset` and verifies it is not an HTML fallback;
3. downloads/converts it with the selected downloader version;
4. produces a local `model.json` package whose referenced `.moc`, textures, motions, expressions, and physics files exist;
5. passes `scripts/validate_live2d_models.mjs`;
6. passes real-browser HomeDeskPet validation.

Static official images, VRM, Spine, video, PNG-only sequences, and resources that cannot be converted into the current Cubism 2 `model.json + .moc` package shape are excluded.

## Key Fields

### `current-pool-coverage.csv`

- `local_code`: character code used by this repository.
- `upstream_code`: character prefix used by Bestdori costume keys. Same as `local_code` for `001-040`; Ave Mujica uses a remap.
- `current_variants`: semicolon-separated variants currently present in `src/data/bangdreamDeskPetPool.json`.
- `manifest_local_pattern`: expected local package path pattern.

### `compatible-candidates-covered-characters.csv`

- `costume_key`: Bestdori costume key.
- `variant`: costume suffix after the upstream character prefix.
- `family`: coarse bucket used for planning.
- `currently_in_pool`: whether this candidate is already represented in the current local pool.
- `available_servers`: Bestdori servers whose index contains this key.
- `bestdori_buildData_url_example`: one example URL, not proof by itself. Later PRs must still verify the response and conversion.
- `recommended_priority`: planning bucket only. `P0` means “good first candidate class”, not “safe to bulk import”.

### `character-candidate-summary.csv`

- `available_compatible_candidates`: count of Bestdori index candidates mapped to the character.
- `current_variants`: current local variant count.
- `missing_candidates`: index candidates not currently represented locally.
- `missing_p0_basic_2023`: basic 2023 clothing/school/casual class.
- `missing_p1_high_value`: birthday/festival/furisode/live_default style high-value classes.
- `missing_p2_event_story`: event/story classes that require visual screening.
- `missing_p3_other`: remaining classes.


### `candidate-resource-intelligence.csv`

This table is meant to preserve as much decision-support information as the current public sources can provide. It is still an audit artifact, not a validation result.

- `bestdori_costume_metadata_found`: whether the costume key was also found in Bestdori `api/costumes/all.5.json`. Some valid `live2d.chara` index candidates are not present in that metadata table; absence here is not proof the package is unavailable.
- `costume_description_*`, `costume_first_published_at_date`, `costume_latest_published_at_date`: Bestdori costume metadata when available.
- `costume_detail_card_ids`: authoritative card references from Bestdori `api/costumes/{id}.json` when the costume detail endpoint exists.
- `title_matched_card_ids`: conservative fallback/cross-check from exact localized-title + character-id matches into Bestdori cards.
- `card_match_method`, `card_ids`, `card_rarities`, `card_types`: final card mapping method and mapped card metadata. Do not match by raw numeric id; costume ids and card ids are different namespaces. `no_match` is explicit and means no card mapping was found in this audit.
- `event_*` and `gacha_*`: event/gacha context inferred from costume keys, reward cards, and card gacha membership where available.
- `real_heat_source`, `real_heat_value`, `real_heat_notes`: real popularity/heat fields. In this snapshot every row is `none_found` because no public costume-key views/favorites/likes/rank source was found.
- `selection_proxy_score`, `selection_proxy_bucket`, `selection_proxy_reasons`: deterministic triage signals based on priority bucket, server coverage, family, matched card rarity/type, event, and gacha context. These fields are **not** popularity.
- `content_rating_scheme`, `source_content_rating`, `final_content_rating`, `needs_manual_content_review`, `content_safety_hint`, `content_policy_decision`: Danbooru-style content-safety review placeholders. All rows default to manual review until a rendered model is inspected.

### `candidate-selection-shortlist.csv`

This file is only a convenience shortlist for the first few resource PRs. It does not replace `candidate-resource-intelligence.csv`, and it does not waive conversion/browser/content review.

### `candidate-intelligence-by-family.csv`

This summary helps decide which costume families are information-rich enough for early PRs. For example, families with high card/event/gacha mapping coverage are easier to explain in PR body and review.

## Ave Mujica Mapping

This repository uses local codes `041-045`, while Bestdori uses upstream prefixes `337-341`:

- `041 -> 341` 豊川 祥子
- `042 -> 337` 三角 初華
- `043 -> 338` 八幡 海鈴
- `044 -> 340` 祐天寺 にゃむ
- `045 -> 339` 若葉 睦

If a future PR downloads an Ave Mujica package, it must rename the upstream prefix to the local code before adding the package to the repo.


## Public Source Snapshots

The intelligence pass checked these public sources on 2026-06-14:

- `https://bestdori.com/api/explorer/{server}/assets/_info.json` for `jp/cn/en/kr/tw` Live2D package indexes.
- `https://bestdori.com/api/costumes/all.5.json` for costume descriptions and publish timestamps.
- `https://bestdori.com/api/costumes/{id}.json` for costume-detail `cards[]` mappings.
- `https://bestdori.com/api/cards/all.5.json` for card rarity, card type, titles, and release timestamps.
- `https://bestdori.com/api/events/all.5.json` for event type, reward cards, characters, and event dates.
- `https://bestdori.com/api/gacha/all.5.json` for gacha type, card membership, and gacha dates.
- `https://bestdori.com/tool/live2d` as the public Live2D viewer reference.
- Danbooru `howto:rate` and upstream code as references for the four-level `general/sensitive/questionable/explicit` rating model.

No checked Bestdori public endpoint exposed costume-key-level popularity, views, favorites, likes, votes, or rank fields. `costumes/{id}.json` adds card references, not heat data. If a future maintainer finds a real source, add it as a separate source column; do not overwrite the existing proxy fields.

## Content Rating Policy

Danbooru-style ratings should be treated as a reference taxonomy: `general`, `sensitive`, `questionable`, `explicit`. In this dataset every candidate remains `final_content_rating=unknown` and `needs_manual_content_review=yes` because no rendered model review was performed in this issue.

Future resource PRs should fail closed:

- do not mark unseen resources as `general`;
- treat filename/family hints such as `swimsuit` as at least `sensitive_review_hint` until visual review proves otherwise;
- only allow direct publication when the rendered bundle has been reviewed and recorded as `final_content_rating=general`;
- quarantine or reject `questionable` and `explicit` resources for the public deskpet pool unless a separate policy explicitly allows them.

## Notes

- Do not parse these CSV files with naive `awk -F,`; some fields contain commas, for example `Hello, Happy World!`.
- Refresh Bestdori indexes before using this dataset for a real PR. This gist is a 2026-06-14 snapshot, not a permanent source of truth.
- Recommended PR size from issue #23: 15-25 new models per PR, with 50 as a soft upper bound only when extra validation evidence is provided.
- Low costume metadata coverage in `candidate-intelligence-by-family.csv` does not imply the Live2D package is absent; `live2d.chara` is still the package source of truth.
- `content_safety_hint` is a filename/family-level hint only. A missing sensitive hint does not mean the rendered model is automatically `general`; every candidate still needs rendered visual review.
